Pravidlá klasickéj dámy(anglickej)
Cieľom hry je vyhodiť všetky súperove figurky.

Klasická dáma sa hrá sa na šachovnici 8x8, pričom každý hráč má na začiatku 12 figúrok (pešiakov) stojacich oproti sebe v prvých dvoch radoch na čiernych políčkach.

Pešiaci sa pohybujú po diagonálach (šikmo) a nesmú preskakovať svoje vlastné figúrky. Pešiak sa môžete pohybovať iba smerom vpred, nesmie "cúvať". 
Pri bežnom ťahu sa figúrky smú pohybovať iba po jednom políčku. 

Vyhodenie súperovej figúrky sa uskutoční jej preskočením. Ak sa v ceste figúrky, ktorá vyhadzuje, nachádza aj ďalšia súperova figúrka, tak ju môže takisto preskočiť. 
Medzi preskakovanými súperovými figúrkami musí byť vždy jedno pole voľné - figúrky nemôžu stáť tesne za sebou. Po každom dopade sa môže zmeniť smer ďalšieho skoku. 

​Ak sa pešiak dostane na druhú stranu šachovnice, stane sa z neho dáma. Tá sa môže pohybovať po diagonálach vpred aj vzad na 1 polé.

Ak mate možnosť vyhodiť súperovu figúrku, tak musite ju vyhodiť.

Hru vyhráva hráč, ktorý zoberie súperovi všetky jeho figúrky. 