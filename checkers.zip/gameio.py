from model import *

"""
This module defines functions for saving
and loading a game.

First line is color of the current player.
Next lines represent 8x8 matrix.
"0" denote empty square,
"b" - black piece,
"B" - black king,
"w" - white piece,
"W" - white king

For example, initial layout:
BLACK
0b0b0b0b
b0b0b0b0
0b0b0b0b
00000000
00000000
w0w0w0w0
0w0w0w0w
w0w0w0w0
"""

"""
Loads the game from filename 
and returns a Model instance.
"""
def load_game(filename):
    model = Model()
    with open(filename) as file:
        lines = file.readlines()
        lines = [line.rstrip() for line in lines]

    if lines[0] == "BLACK":
        model.current = Color.BLACK
    elif lines[0] == "WHITE":
        model.current = Color.WHITE
    else:
        raise BaseException("Invalid input file.")

    for i in range(ROWS):
        line = lines[i + 1]
        for j in range(len(line)):
            p = line[j]
            if p == 'b':
                model.add_piece(Piece(i, j, Color.BLACK))
            elif p == 'B':
                model.add_piece(Piece(i, j, Color.BLACK, Crown.KING))
            elif p == 'w':
                model.add_piece(Piece(i, j, Color.WHITE))
            elif p == 'W':
                model.add_piece(Piece(i, j, Color.WHITE, Crown.KING))
            elif p == '0':
                pass
            else:
                raise BaseException("Invalid input file.")

    return model


"""
Saves the game from the model to the filename.
"""
def save_game(filename, model):
    with open(filename, "w") as file:
        if model.current == Color.BLACK:
            file.write("BLACK\n")
        else:
            file.write("WHITE\n")

        for i in range(ROWS):
            line = ""
            for j in range(COLS):
                p = model.piece(i, j)
                if p == None:
                    line += "0"
                elif p.is_black():
                    if p.is_king():
                        line += "B"
                    else:
                        line += "b"
                else:
                    if p.is_king():
                        line += "W"
                    else:
                        line += "w"
            line += "\n"
            file.write(line)
