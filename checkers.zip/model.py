from enum import Enum

"""This module defines the 'Checkers' model

The model has several entities:
 - Piece - has (row, col) position, BLACK or WHITE, MAN or KING
 - Board - has the ROWS * COLS matrix of Pieces
 - Player - BLACK or WHITE, stores a list of pieces of its own color
 - Model - has two Players, the Board and the color of the current player
 - Move - stores start position and end position of a move
"""

"""The number of rows on the board."""
ROWS = 8


"""The number of columns on the board."""
COLS = 8


"""The Color of the Piece and of the Player."""
class Color(Enum):
    BLACK = 0
    WHITE = 1


"""The 'crown' of the Piece."""
class Crown(Enum):
    MAN = 0
    KING = 1


"""The Move class

Stores start position and end position of a move.
"""
class Move():
    """Constructor"""
    def __init__(self, row, col, new_row, new_col):
        self.row = row
        self.col = col
        self.new_row = new_row
        self.new_col = new_col


"""The Piece class

Stores (row, col) position, BLACK or WHITE, MAN or KING.
"""
class Piece():
    """Constructor."""
    def __init__(self, row, col, color, crown=Crown.MAN):
        self.row = row
        self.col = col
        self.color = color
        self.crown = crown

    """Returns True if the piece is BLACK"""
    def is_black(self):
        return self.color == Color.BLACK

    """Returns True if the piece is WHITE"""
    def is_white(self):
        return self.color == Color.WHITE

    """Returns True if the piece is KING"""
    def is_king(self):
        return self.crown == Crown.KING

    """Improves the MAN to the KING"""
    def coronate(self):
        self.crown = Crown.KING


"""The Player class

BLACK or WHITE, stores a list of pieces of its own color.
"""
class Player():
    """Constructor."""
    def __init__(self, color):
        self.color = color
        self.pieces = []


"""The Board class

Stores the ROWS * COLS matrix of Pieces
"""
class Board():
    """Constructor"""
    def __init__(self):
        # Create an empty ROWS * COLS matrix
        self.matrix = [[None for j in range(COLS)] for i in range(ROWS)]

    """
    Returns True if the (row, col) square 
    is empty (not occupied by a piece).
    """
    def is_empty(self, row, col):
        if self.matrix[row][col]:
            return False
        return True

    """
    Returns a Piece on the (row, col) square.
    If the square is empty then returns None.
    """
    def get(self, row, col):
        return self.matrix[row][col]

    """Places the piece at a new (new_row, new_col) position"""
    def place(self, piece, new_row, new_col):
        if not self.is_empty(new_row, new_col):
            raise BaseException("Unable to place a piece on non-empty square")
        self.matrix[new_row][new_col] = piece
        piece.row = new_row
        piece.col = new_col

    """Removes the piece from the board."""
    def remove(self, piece):
        self.matrix[piece.row][piece.col] = None

"""The Model class

Has two Players, the Board and the color of the current player.
Has a lot of function to control the model.
"""
class Model():
    
    """Constructor. Creates an empty model (without any piece)"""
    def __init__(self):
        self.black_player = Player(Color.BLACK)
        self.white_player = Player(Color.WHITE)
        self.board = Board()
        self.current = Color.BLACK

    
    """
    Adds the piece to the model.
    """
    def add_piece(self, piece):
        # Add to the corresponding player's pieces
        if piece.is_black():
            self.black_player.pieces.append(piece)
        else:
            self.white_player.pieces.append(piece)
        # Place at the board
        self.board.place(piece, piece.row, piece.col)

    
    """
    Removes the piece from the model.
    """
    def remove(self, piece):
        # Remove from the corresponding player's pieces
        if piece.is_black():
            self.black_player.pieces.remove(piece)
        else:
            self.white_player.pieces.remove(piece)
        # Remove from the board
        self.board.matrix[piece.row][piece.col] = None
    
    
    """
    Returns a Piece on the (row, col) square.
    If the square is empty then returns None.
    """
    def piece(self, row, col):
        return self.board.get(row, col)

    
    """
    Returns the Color of the Piece on the (row, col) square.
    If the square is empty then returns None.
    """
    def color(self, row, col):
        if self.board.get(row, col) == None:
            return None
        return self.board.get(row, col).color    

    
    """
    Switches the current player.
    """
    def turn(self):
        if self.current == Color.BLACK:
            self.current = Color.WHITE
        else:
            self.current = Color.BLACK
    
    
    """
    Returns True if the (row, col) square is valid.
    The valid square is within the boundaries of the board.
    """
    def is_valid(self, row, col):
        return row >= 0 and row < ROWS and col >= 0 and col < COLS

    
    """
    Returns True if the (row, col) square is empty.
    """
    def is_empty(self, row, col):
        return self.is_valid(row, col) and self.board.is_empty(row, col)

    
    """
    Returns True if (new_row, new_col) square
    is valid move for the given piece.
    According to the rules, a piece can move 
    diagonally forward one square. 
    The king can also move backward 
    (also diagonally and one square).
    The destination square must be empty.
    """
    def is_move(self, piece, new_row, new_col):        
        if not self.is_valid(new_row, new_col):
            return False # out of range

        # KING case
        if piece.is_king():
            if (abs(new_row - piece.row) == 1
                    and abs(new_col - piece.col) == 1):
                return self.is_empty(new_row, new_col)
            else:
                return False

        # BLACK case
        if piece.is_black():
            if (new_row == piece.row + 1
                    and abs(new_col - piece.col) == 1):
                return self.is_empty(new_row, new_col)
            else:
                return False

        # WHITE case
        if piece.is_white():
            if (new_row == piece.row - 1
                    and abs(new_col - piece.col) == 1):
                return self.is_empty(new_row, new_col)
            else:
                return False

        return False

    
    """
    Returns True if (new_row, new_col) square
    is valid capturing move for the given piece.

    The player can choose to capture by choosing 
    one of two squares - either the one where 
    the captured piece is located, or the one where
    the capturing piece will move after the capture.
    Those two cases are handled separately 
    with two helper functions.

    According to the rules, a piece can capture 
    an enemy piece diagonally forward one square 
    by jumping over it. One piece can make several 
    captures per turn if there is a chain of enemy 
    pieces that can be captured in turn. 
    The king can also capture backwards 
    (also diagonally and one square) and 
    it can move in a zigzag when capturing 
    several pieces per turn.
    """
    def is_capture(self, piece, new_row, new_col):
        if not self.is_valid(new_row, new_col):
            return False # out of range

        # KING case
        if piece.is_king():
            if abs(new_row - piece.row) == 1:
                return self.is_capture_1(piece, new_row, new_col)
            elif abs(new_row - piece.row) == 2:
                return self.is_capture_2(piece, new_row, new_col)
            else:
                return False

        # BLACK case
        if piece.is_black():
            if new_row == piece.row + 1:
                return self.is_capture_1(piece, new_row, new_col)
            elif new_row == piece.row + 2:
                return self.is_capture_2(piece, new_row, new_col)
            else:
                return False

        # WHITE case
        if piece.is_white():
            if new_row == piece.row - 1:
                return self.is_capture_1(piece, new_row, new_col)
            elif new_row == piece.row - 2:
                return self.is_capture_2(piece, new_row, new_col)
            else:
                return False

        return False
    
    
    """
    A helper function to determine 
    if a given move is a capture. 
    This handles the case when 
    the (row, col) points to a captured piece.
    """
    def is_capture_1(self, piece, row, col):
        if (self.is_empty(row, col)
                or self.piece(row, col).color == piece.color):
            return False # No target on the (row, col) square

        # Calculate position of the landing square
        
        if piece.is_king():
            if row > piece.row:
                y_dir = 1
            else:
                y_dir = -1
        elif piece.is_black():
            y_dir = 1
        elif piece.is_white():
            y_dir = -1

        if col == piece.col + 1:
            x_dir = 1
        elif col == piece.col - 1:
            x_dir = -1
        else:
            return False

        # Destination should be empty.
        return self.is_empty(row + y_dir, col + x_dir)

    
    """
    A helper function to determine 
    if a given move is a capture. 
    This handles the case when 
    the (row, col)) points to an empty square 
    after the captured piece (where the 
    capturing piece should move after capturing).
    """
    def is_capture_2(self, piece, row, col):
        if not self.is_empty(row, col):
            return False # Destination is not empty
        
        # Calculate position of the captured square
        
        if piece.is_king():
            if row > piece.row:
                r1 = piece.row + 1
            else:
                r1 = piece.row - 1
        elif piece.is_black():
            r1 = piece.row + 1
        elif piece.is_white():
            r1 = piece.row - 1

        if col == piece.col + 2:
            c1 = piece.col + 1
        elif col == piece.col - 2:
            c1 = piece.col - 1
        else:
            return False

        # Captured square should has a target
        return (not self.is_empty(r1, c1) and
                self.piece(r1, c1).color != piece.color)    

    
    """Moves the piece to a new (row, col) position."""
    def make_move(self, piece, row, col):
        self.board.remove(piece)
        self.board.place(piece, row, col)

        # check if need to coronate a MAN
        if not piece.is_king():
            if ((piece.is_black() and piece.row == ROWS - 1) or
                    (piece.is_white() and piece.row == 0)):
                piece.coronate()

    
    """
    Captures a piece on (row, col) square 
    by the given piece.
    The player can choose to capture by choosing 
    one of two squares - either the one where 
    the captured piece is located, or the one where
    the capturing piece will move after the capture.
    Those two cases are handled separately 
    with two helper functions.
    """
    def make_capture(self, piece, row, col):
        self.board.remove(piece)

        if abs(piece.row - row) == 1:
            self.make_capture1(piece, row, col)
        elif abs(piece.row - row) == 2:
            self.make_capture2(piece, row, col)

        # check if need to coronate a MAN
        if not piece.is_king():
            if ((piece.is_black() and piece.row == ROWS - 1) or
                    (piece.is_white() and piece.row == 0)):
                piece.coronate()
    
    
    """
    Captures a piece on (row, col) square 
    by the given piece.
    This handles the case when 
    the (row, col) points to a captured piece.
    """
    def make_capture1(self, piece, row, col):
        if piece.is_king():
            if row > piece.row:
                newrow = row + 1
            else:
                newrow = row - 1
        elif piece.is_black():
            newrow = row + 1
        else:
            newrow = row - 1

        if col == piece.col + 1:
            newcol = col + 1
        else:
            newcol = col - 1

        self.remove(self.piece(row, col))
        self.board.place(piece, newrow, newcol)

    
    """
    Captures a piece on (row, col) square 
    by the given piece.
    This handles the case when 
    the (row, col)) points to an empty square 
    after the captured piece (where the 
    capturing piece should move after capturing).
    """
    def make_capture2(self, piece, row, col):
        if piece.is_king():
            if row > piece.row:
                r1 = piece.row + 1
            else:
                r1 = piece.row - 1
        elif piece.is_black():
            r1 = piece.row + 1
        else:
            r1 = piece.row - 1

        if col == piece.col + 2:
            c1 = piece.col + 1
        else:
            c1 = piece.col - 1

        self.remove(self.piece(r1, c1))
        self.board.place(piece, row, col)    

    
    """
    Returns a list of adjacent squares for the piece.
    Each item in the list is [row, col] array.
    """
    def get_adjacent(self, piece):
        adjacent = []
        
        if piece.is_king():
            # for KING
            adjacent.append((piece.row + 1, piece.col + 1))
            adjacent.append((piece.row + 1, piece.col - 1))
            adjacent.append((piece.row - 1, piece.col + 1))
            adjacent.append((piece.row - 1, piece.col - 1))
        elif piece.is_black():
            # for BLACK
            adjacent.append((piece.row + 1, piece.col + 1))
            adjacent.append((piece.row + 1, piece.col - 1))
        elif piece.is_white():
            # for WHITE
            adjacent.append((piece.row - 1, piece.col + 1))
            adjacent.append((piece.row - 1, piece.col - 1))

        return adjacent

    
    """
    Returns a list of all available 
    moves for the given color.
    """
    def get_moves(self, color):
        moves = []

        if color == Color.BLACK:
            pieces = self.black_player.pieces
        else:
            pieces = self.white_player.pieces

        for piece in pieces:
            for (new_row, new_col) in self.get_adjacent(piece):
                if self.is_move(piece, new_row, new_col):
                    mv = Move(piece.row, piece.col, new_row, new_col)
                    moves.append(mv)

        return moves

    
    """
    Returns a list of all available 
    captures for the given color.
    """
    def get_captures(self, color):
        captures = []

        if color == Color.BLACK:
            pieces = self.black_player.pieces
        else:
            pieces = self.white_player.pieces
        
        for piece in pieces:
            for (new_row, new_col) in self.get_adjacent(piece):
                if self.is_capture(piece, new_row, new_col):
                    mv = Move(piece.row, piece.col, new_row, new_col)
                    captures.append(mv)

        return captures

    
    """
    Returns True if the given color has 
    at least one available move.
    """
    def has_moves(self, color):
        return len(self.get_moves(color)) > 0

    
    """
    Returns True if the given color has 
    at least one available capture.
    """
    def has_captures(self, color):
        return len(self.get_captures(color)) > 0

    
    """
    Returns True if the given piece 
    has ability to capture a piece.
    """
    def can_capture(self, piece):
        for (new_row, new_col) in self.get_adjacent(piece):
            if self.is_capture(piece, new_row, new_col):
                return True
        return False

    
    """
    Returns True if the current player 
    has no available moves.
    """
    def is_gameover(self):
        return not (self.has_moves(self.current)
                    or self.has_captures(self.current))    
