from model import *

"""
This module defines functions
for drawing the board and pieces.
"""

"""Board width"""
WIDTH = 500

"""Board height"""
HEIGHT = 500


"""
Draws a man piece on the canvas 
using ovals and lines.
(x, y) is center of the piece.
'fill' is fill color.
'outl' is outline color. 
"""
def draw_man(canvas, x, y, fill, outl):
    (W, H, D) = (32, 24, 10)

    canvas.create_oval(x - W/2, y - H/2 + D,
                       x + W/2, y + H/2 + D,
                       outline=outl, fill=fill, width=1)
    canvas.create_oval(x - W/2, y - H/2,
                       x + W/2, y + H/2,
                       outline=outl, fill=fill, width=1)
    canvas.create_oval(x - W/2 + 4, y - H/2 + 4,
                       x + W/2 - 4, y + H/2 - 4,
                       outline=outl, fill=fill, width=1)
    canvas.create_oval(x - W/2 + 8, y - H/2 + 8,
                       x + W/2 - 8, y + H/2 - 8,
                       outline=outl, fill=fill, width=1)
    canvas.create_line(x - W/2 + 1, y,
                       x - W/2 + 1, y + D,
                       fill=outl, width=2)
    canvas.create_line(x + W/2, y,
                       x + W/2, y + D,
                       fill=outl, width=2)


"""
Draws a king piece on the canvas 
using ovals and lines.
(x, y) is center of the piece.
'fill' is fill color.
'outl' is outline color. 
"""
def draw_king(canvas, x, y, fill, outl):
    (W, H, D) = (32, 24, 10)

    canvas.create_oval(x - W/2, y - H/2 + D,
                       x + W/2, y + H/2 + D,
                       outline=outl, fill=fill, width=1)
    canvas.create_oval(x - W/2, y - H/2,
                       x + W/2, y + H/2,
                       outline=outl, fill=fill, width=1)
    canvas.create_oval(x - W/2, y - H/2 - D,
                       x + W/2, y + H/2 - D,
                       outline=outl, fill=fill, width=1)
    canvas.create_oval(x - W/2 + 4, y - H/2 - D + 4,
                       x + W/2 - 4, y + H/2 - D - 4,
                       outline=outl, fill=fill, width=1)
    canvas.create_oval(x - W/2 + 8, y - H/2 - D + 8,
                       x + W/2 - 8, y + H/2 - D - 8,
                       outline=outl, fill=fill, width=1)
    canvas.create_line(x - W/2 + 1, y,
                       x - W/2 + 1, y + D,
                       fill=outl, width=2)
    canvas.create_line(x + W/2, y,
                       x + W/2, y + D,
                       fill=outl, width=2)
    canvas.create_line(x - W/2 + 1, y,
                       x - W/2 + 1, y - D,
                       fill=outl, width=2)
    canvas.create_line(x + W/2, y,
                       x + W/2, y - D,
                       fill=outl, width=2)


"""Draws a black man with center at (x, y)"""
def draw_black_man(canvas, x, y):
    draw_man(canvas, x, y, 'black', 'white')


"""Draws a white man with center at (x, y)"""
def draw_white_man(canvas, x, y):
    draw_man(canvas, x, y, 'white', 'black')


"""Draws a black king with center at (x, y)"""
def draw_black_king(canvas, x, y):
    draw_king(canvas, x, y, 'black', 'white')


"""Draws a white king with center at (x, y)"""
def draw_white_king(canvas, x, y):
    draw_king(canvas, x, y, 'white', 'black')


"""
Draws a piece on the canvas 
using ovals and lines.
"""
def draw_piece(canvas, color, x, y, is_king):
    if color == Color.BLACK:
        if is_king:
            draw_black_king(canvas, x, y)
        else:
            draw_black_man(canvas, x, y)
    else:
        if is_king:
            draw_white_king(canvas, x, y)
        else:
            draw_white_man(canvas, x, y)


"""
Draws the board and all pieces on the canvas.
'selected' points to a piece currently selected by a player
(x, y) is coordinates of the mouse pointer (in canvas coordinates) 
"""
def draw_board(canvas, model, board_img, selected=None, x=0, y=0):
    # clear canvas
    canvas.delete('all')
    
    # draw board
    canvas.create_image(WIDTH // 2, HEIGHT // 2, image=board_img)
    step_x = WIDTH // COLS
    step_y = HEIGHT // ROWS

    # draw black pieces
    for p in model.black_player.pieces:
        if p != selected:
            # find center of the square
            (x0, y0) = (p.col*step_x + step_x/2, p.row*step_y + step_y/2)
            draw_piece(canvas, Color.BLACK, x0, y0, p.is_king())

    # draw white pieces
    for p in model.white_player.pieces:
        if p != selected:
            # find center of the square
            (x0, y0) = (p.col*step_x + step_x/2, p.row*step_y + step_y/2)
            draw_piece(canvas, Color.WHITE, x0, y0, p.is_king())

    # draw the selected piece separately, at the (x, y) position
    if selected:
        draw_piece(canvas, selected.color, x, y, selected.is_king())
