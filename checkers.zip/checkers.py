# Standard modules
import tkinter as tk
from tkinter import messagebox as mb
from tkinter import filedialog as fd
import winsound as ws
from time import sleep
from threading import Thread
from datetime import datetime

# My modules
from model import *
from view import *
from gameio import *
from ai import *

"""
This module implements the 'Checkers" game using tkinter.
"""


"""
This class is a descendant of the top-level Tk() window.
"""
class Checkers(tk.Tk):

    """Defines available game modes."""
    class Mode(Enum):
        PvC = 0
        PvP = 1

    
    """Constructor."""
    def __init__(self):
        super().__init__()
        
        # configure the main window
        self.title("Checkers")
        self.resizable(width=False, height=False)

        # configure rows and columns of the grid layout
        self.columnconfigure([0, 2], weight=1, minsize=40)
        self.rowconfigure([0, 2], weight=1, minsize=40)
        self.columnconfigure(1, weight=1, minsize=WIDTH)
        self.rowconfigure(1, weight=1, minsize=HEIGHT)

        self.init_variables()

        self.init_controls()

        self.init_menu()

        self.eval('tk::PlaceWindow . center')        

        self.new_game() # start a new game

    
    """Creates the instance variables."""
    def init_variables(self):
        # Observable variables
        self.mode = tk.IntVar()        
        self.black_var = tk.StringVar()
        self.white_var = tk.StringVar()
        self.curr_var = tk.StringVar()        

        # Load the board image
        self.board_img = tk.PhotoImage(file="./res/board.png")        
        
         # default mode is PvC
        self.mode.set(self.Mode.PvC.value)
        # a piece selected by the player
        self.selected = None
        # x of selected piece
        self.selcted_x = 0 
        # y of selected piece
        self.selcted_y = 0 
        # if the currently selected piece 
        # is in the process of capturing other pieces
        self.capturing = False
    
    
    """Initializes the game controls."""
    def init_controls(self):
        # The frame on which the canvas is laid
        self.board_frame = tk.Frame(
            master=self,
            relief=tk.GROOVE,
            borderwidth=2
        )
        self.board_frame.grid(row=1, column=1, padx=0, pady=0)

        # The canvas on which the board and figures are drawn
        self.canvas = tk.Canvas(
            self.board_frame, width=WIDTH, height=HEIGHT, bg="#FFFFDD")
        self.canvas.pack()
        
        # Bind the canvas events
        self.canvas.bind("<Motion>", self.on_motion)
        self.canvas.bind("<ButtonPress-1>", self.on_press)
        
        # Displays the counter of capturing pieces for the black player
        self.black_lbl = tk.Label(
            master=self,
            width = 10,
            fg="white",
            bg="black",
            textvariable=self.black_var            
        )
        self.black_lbl.grid(row=0, column=0, padx=0, pady=0)
        
        # Displays the counter of capturing pieces for the white player
        self.white_lbl = tk.Label(
            master=self,
            width = 10,
            fg="black",
            bg="white",            
            textvariable=self.white_var           
        )
        self.white_lbl.grid(row=0, column=2, padx=0, pady=0)
        
        # Displays the color of the current player
        self.curr_lbl = tk.Label(
            master=self,
            textvariable=self.curr_var           
        )
        self.curr_lbl.grid(row=0, column=1, padx=0, pady=0)

    
    """Initializes the menu system."""
    def init_menu(self):
        # Main Menu
        menu = tk.Menu(self)
        self.config(menu=menu)

        # File Menu
        file_menu = tk.Menu(menu, tearoff=False)
        menu.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="New", command=self.new_game)
        file_menu.add_command(label="Load...", command=self.load_game)
        file_menu.add_command(label="Save", command=self.save_game)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.exit_prog)

        # Mode Menu
        mode_menu = tk.Menu(menu, tearoff=False)
        menu.add_cascade(label="Mode", menu=mode_menu)        
        mode_menu.add_radiobutton(
            label="Player vs. Computer", 
            var=self.mode, 
            value=self.Mode.PvC.value)
        mode_menu.add_radiobutton(
            label="Player vs. Player", 
            var=self.mode, 
            value=self.Mode.PvP.value)

    
    """Updates top panel containing the game information."""
    def update_info(self):
        if self.model.current == Color.BLACK:
            self.curr_var.set("Black")
        else:
            self.curr_var.set("White")
        
        # calculate a number of captured pieces
        captured_white = 12 - len(self.model.white_player.pieces)
        captured_black = 12 - len(self.model.black_player.pieces)

        self.black_var.set(f"Black: {captured_white}")
        self.white_var.set(f"White: {captured_black}")

    
    """Updates the window."""
    def update_all(self):
        self.update_info()
        draw_board(self.canvas, self.model, self.board_img, 
                 self.selected, self.selcted_x, self.selcted_y)

    
    """Redraws the board."""
    def update_booard(self):        
        draw_board(self.canvas, self.model, self.board_img,
                 self.selected, self.selcted_x, self.selcted_y)

    
    """
    <Motion> event handler for the canvas.
    It redraws the board if a piece is selected by the user.
    """
    def on_motion(self, event):
        if self.selected:
            (self.selcted_x, self.selcted_y) = (event.x, event.y)
            self.update_booard()

    """
    <ButtonPress-1> event handler for the canvas.
    The first press selects the piece under the cursor, 
    the second press tries to drop 
    the piece on the square under the cursor.
    """
    def on_press(self, event):             
        row = event.y // (HEIGHT // ROWS)
        col = event.x // (WIDTH // COLS)

        if not self.selected:
            self.try_select(self.model, row, col)
        else:
            self.try_move(self.model, row, col)  
    
    
    """
    Tries to select a piece if the player 
    presses mouse button on the square.
    Plays a sound if there is no piece on the square.
    """
    def try_select(self, model, row, col):
        if not model.is_empty(row, col):
            if model.color(row, col) == model.current:
                self.selected = model.piece(row, col)                    
            else:
                Checkers.play_error_sound()
    
    
    """
    Tries to make a move or capture to the given square.
    Plays different sounds for different outcomes.
    """
    def try_move(self, model, row, col):
        success = False

        # Try move or capture
        if self.selected and not self.capturing:
            success = self.try_move_or_capture(model, row, col)
        elif self.capturing:
            success = self.try_capture_next(model, row, col)
        
        if not success:
            Checkers.play_error_sound()
        
        self.update_all()

        if success and not self.capturing:
            # check game over
            if self.model.is_gameover():
                self.game_over(self.model.current)
            else:
                # Pass the move to AI if the corresponding mode is enabled.
                if (self.mode.get() == self.Mode.PvC.value 
                        and self.model.current == Color.WHITE):
                    self.begin_ai()
    
    
    """
    Tries to make a move or capture to the given square. 
    Plays different sounds for different outcomes.   
    """
    def try_move_or_capture(self, model, row, col):
        success = True
        if (model.is_move(self.selected, row, col)
                and not model.has_captures(model.current)):
            # Move case
            model.make_move(self.selected, row, col)
            self.selected = None            
            Checkers.play_move_sound()            
            model.turn()
        elif model.is_capture(self.selected, row, col):
            # Capture case
            model.make_capture(self.selected, row, col)            
            Checkers.play_capture_sound()
            # check if this piece can capture the next piece(s)
            if model.can_capture(self.selected):
                self.capturing = True
            else:                   
                self.selected = None
                model.turn()
        else:
            success = False
            self.selected = None            
        
        return success

    
    """
    Tries to capture a next piece in a chain.
    """
    def try_capture_next(self, model, row, col):
        success = True
        if model.is_capture(self.selected, row, col):
            model.make_capture(self.selected, row, col)            
            Checkers.play_capture_sound()
            # check if this piece can capture the next piece(s)
            if not model.can_capture(self.selected):                    
                self.capturing = False
                self.selected = None
                model.turn()
        else:
            success = False            
        
        return success   

    """
    AI makes a move in a separate thread 
    so as not to block the main thread during this.
    During an AI turn, canvas events 
    are temporarily disabled.
    """
    def begin_ai(self):
        # disable the canvas events
        self.canvas.unbind("<Motion>")
        self.canvas.unbind("<ButtonPress-1>")

        # start new thread
        new_thread = Thread(target=self.ai_thread_proc)
        new_thread.start()
    
    
    """
    AI makes a move in a separate thread 
    so as not to block the main thread during this.
    During an AI turn, canvas events 
    are temporarily disabled. 
    Small delays are made there 
    to make the AI behavior look more natural.
    """
    def ai_thread_proc(self):
        sleep(1)

        model = self.model

        # Ask the AI for the next move
        (piece, new_row, new_col) = select_move(model, model.current)

        if model.is_move(piece, new_row, new_col):
            # Move case
            model.make_move(piece, new_row,new_col)            
            Checkers.play_move_sound()
        elif model.is_capture(piece, new_row, new_col):
            # Capture case
            model.make_capture(piece, new_row, new_col)            
            Checkers.play_capture_sound()

            # check capture chain
            while model.can_capture(piece):
                self.update_all()
                sleep(1)
                (new_row, new_col) = select_capture(model, piece)
                model.make_capture(piece, new_row, new_col)            
                Checkers.play_capture_sound()

        model.turn()
        self.update_all()

        sleep(1)
        
        # enable the canvas events
        self.canvas.bind("<Motion>", self.on_motion)
        self.canvas.bind("<ButtonPress-1>", self.on_press)

        # Check game over
        if model.is_gameover():
            self.game_over(self.model.current)             
               

    """
    Handles the Game Over case.
    Displays a message and starts a new game.
    """
    def game_over(self, player):
        Checkers.play_gameover_sound()
        if player == Color.BLACK:
            winner = "WHITE"
        else:
            winner = "BLACK"
        mb.showinfo("Chekers", f"{winner} wins!", parent=self)
        self.new_game()
            
    
    """
    Starts a new game by loading the initial layout from the file.
    """
    def new_game(self):
        self.model = load_game("./saves/initial.txt")
        self.selected = None
        self.update_all()

    
    """
    Loads a saved game from the file.
    """
    def load_game(self):
        filename = fd.askopenfilename(initialdir='./saves')
        if filename:
            try:
                self.model = load_game(filename)
            except BaseException:
                mb.showerror("Chekers", "Invalid input file", parent=self)
            self.selected = None
            self.update_all()

    
    """
    Saves the current game to the file.
    """
    def save_game(self):
        filename = "./saves/" + datetime.now().strftime("%m-%d-%Y--%H-%M-%S") + ".txt"
        save_game(filename, self.model)
        print(f"Saved to '{filename}'")

    
    """
    Exits the program.
    """
    def exit_prog(self):
        self.destroy()    

    
    """
    Plays a sound when the user tries to make an invalid action.
    """
    def play_error_sound():
        ws.PlaySound('./res/error.wav', ws.SND_FILENAME | ws.SND_ASYNC)
    
    
    """
    Plays a sound when the user makes a move.
    """
    def play_move_sound():
        ws.PlaySound('./res/move.wav', ws.SND_FILENAME | ws.SND_ASYNC)
    
    
    """
    Plays a sound when the user makes a capture.
    """
    def play_capture_sound():
        ws.PlaySound('./res/tada.wav', ws.SND_FILENAME | ws.SND_ASYNC)
    
    
    """ 
    Plays a sound when the game over.
    """
    def play_gameover_sound():
        ws.PlaySound('./res/gameover.wav', ws.SND_FILENAME | ws.SND_ASYNC)


# Starts the program
checkers = Checkers()
checkers.mainloop()
