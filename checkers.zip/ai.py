from random import randint
from model import *

"""AI module.
Here, the functions of choosing 
the next move for the AI are implemented.
It simply selects a random move 
from a list of possible moves.
"""

"""
Selects a next move for the color 
using the model.
"""
def select_move(model, color):
    # select from available captures first
    captures = model.get_captures(color)
    if len(captures) > 0:
        # select a random capture from the list
        capture = captures[randint(0, len(captures) - 1)]
        selected = model.piece(capture.row, capture.col)
        return (selected, capture.new_row, capture.new_col)

    # if threre are no available captures then select from available moves
    moves = model.get_moves(color)
    if len(moves) > 0:
        # select a random move from the list
        move = moves[randint(0, len(moves) - 1)]
        selected = model.piece(move.row, move.col)
        return (selected, move.new_row, move.new_col)

    return None


"""
Selects a next capture in a capture chain 
for the capturing piece.
"""
def select_capture(model, piece):
    captures = []
    for (new_row, new_col) in model.get_adjacent(piece):
        if model.is_capture(piece, new_row, new_col):
            captures.append((new_row, new_col))
    # select a random capture from the list
    capture = captures[randint(0, len(captures) - 1)]
    return capture
